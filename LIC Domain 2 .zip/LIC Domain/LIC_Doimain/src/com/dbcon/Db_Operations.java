package com.dbcon;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.domain.Users;
   //CRUD operations happens Here!.
   public class Db_Operations {
  

    private static int r = 0;


	/*This insertUsers1(Users u) used accepts Users object u as parameter.  
	Establishes Connection with Sql Server and Inserts 5 Values into table  tb_users of db_lic database
	using Prepared Statement  */
	public static int insertUsers(Users u) throws Exception 
	{
		  //Creating the connection 
		Connection con=null;	
		ResultSet rs=null;
		PreparedStatement pt = null;
		 
		try {
			//assigning connection class method to con establish connection with database.
			con=Connect.getConnection();
			String ins=SqlQueries.ins;                // fetching sql query from SqlQueries Class.
			pt= PreparedClass.insert(con, ins,u);	 // calls PreparedClass to access prepared statements and set Values.				  
			r=pt.executeUpdate();
			rs = pt.getGeneratedKeys();
			displayKey(rs);               //method to display a value using Resultset 
			
		} 
		catch ( Exception ex) 
		{
			System.out.println(" Enter Valid Policy No");

		}   
		
        finally {
        			 pt.close();
		        	 rs.close();
		             con.close();
        		}
		return r;
			
		}

	
	 


	/*This display(Users u) Method  accepts Users object u as parameter.
	    Establishes Connection with Sql Server and Fetchs All Values into table  tb_users of db_lic database
		using Prepared Statement  */
	public static void read(Users u) throws SQLException {
		
			  ResultSet rs=null;
			  Connection con=null;
			  PreparedStatement pt = null;
			try {		
				//assigning connection class method to con establish connection with database 
				  con=Connect.getConnection();
				  String dis=SqlQueries.disp;             // fetching sql query from SqlQueries Class.
				  pt= PreparedClass.display(con, dis,u); // calls PreparedClass to access prepared statements and set Values				  					
				  rs = pt.executeQuery();
				  displayRes(rs);
			  
			} 
			catch ( Exception ex) 
			{
				System.out.println(" Enter Valid Policy No");

			}   
			
	        finally {
	        			 pt.close();
			        	 rs.close();
			             con.close();
	        		}

				
			}

	 /*This update(Users u) Method accepts Users object u as parameter. Establishes
       Connection with Sql Server and updates Premium_Type based on users Policy_Number 
       in the table  tb_users of db_lic database using Prepared Statement  */
	public static int update(Users u) throws SQLException {
		
		Connection con=null;
		PreparedStatement pt = null;
			
			try 
			{     //assigning connection class method to con establish connection with database 
				  con=Connect.getConnection();
				  String up=SqlQueries.updat;            // fetching sql query from SqlQueries Class.
				  pt= PreparedClass.update(con, up,u);  // calls PreparedClass to access prepared statements and set Values				  					
				  r = pt.executeUpdate();
				  read(u);
				
			} 
			catch (Exception ex) 
			{
				System.out.println("Database Error!!");
				ex.printStackTrace();
			}  	
		   finally {
			     pt.close();
	             con.close();
		           }
			return r;
				
		}	



	/*This delete(Users u) Method accepts Users object u as parameter.Establishes 
	  Connection with Sql Server and deletes particular row based on users Policy_Number 
      in the table  tb_users of db_lic database using Prepared Statement  */
	public static int delete(Users u) throws Exception {
		
	    Connection con=null;
	    PreparedStatement pt = null;
		
		  try
	      {   //assigning connection class method to con establish connection with database 
			  con=Connect.getConnection();
			  String del=SqlQueries.del;                 // fetching sql query from SqlQueries Class.
			  pt= PreparedClass.delete(con, del,u);  	// calls PreparedClass to access prepared statements and set Values					  					
			  r = pt.executeUpdate();
  	    
	  		}
		  catch (Exception ex) 
			{
				System.out.println("Database Error");
				ex.printStackTrace();
			}   
	     
	      finally { 
	    	   		pt.close();
	    	  		con.close();
		          }
		return r;
				
			}




//>>>>>>>>>>>>>>>>>>>>>>>>>>Display Methods which accepts ResultSet as parameter.
//--------------------------Result Set Methods To Fetch data from database and to display on Console----------------------------------------------
	private static void displayRes(ResultSet rs)
	{
		
		try {
			if(rs.next()){
			       //Retrieve by column name
					  
			       int pno= rs.getInt("Policy_Number");
			       String pname = rs.getString("Policy_Name");
			       String phname = rs.getString("Policy_Holder_Name");  
			       String pdate=rs.getString("Policy_Start_Date");
			       float pamount = rs.getFloat("Premium_Amount");
			       String ptype = rs.getString("Premium_Type");

			       //Display values
			       System.out.println("Policy_Number:      " + pno);
			       System.out.println("Policy_Name:        " + pname);
			       System.out.println("Policy_Holder_Name: " + phname);
			       System.out.println("Policy_Start_Date:  " + pdate);
			       System.out.println("Premium_Amount:     " + pamount);
			       System.out.println("Premium_Type:       " + ptype);
			   
			    } 
				  else
				  {
					  System.out.println("Invalid!! .Please Enter valid Policy No:");
				  }
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
	
	//Displaying Generated key value on successful Insertion of data into database
	 private static void displayKey(ResultSet rs) {


			  try {
				if(rs != null && rs.next()){
						System.out.println();
						System.out.println();
						System.out.println("Congrats!! your Generated policy number: "+rs.getInt(1));
				    	System.out.println("**************************************");
					}
				else {
					System.out.println("There was an Error while Insertion ");
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			  
		}
	
}
	
	
	

