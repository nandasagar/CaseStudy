package com.dbcon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
// class to instantiate Connection with Database and returns an connection object.
public class Connect {
	
	private static String url = "jdbc:mysql://localhost:3306/db_lic"; 
	private static String user = "root"; 
    private static String pass = "Nanda$105"; 
    private static String driverName="com.mysql.jdbc.Driver";  
    private static Connection con;
    
    public static Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
                con = DriverManager.getConnection(url, user, pass);
            } catch (SQLException ex) {
                
                System.out.println("Failed to create the database connection."); 
            }
        } catch (ClassNotFoundException ex) {
            
            System.out.println("Driver not found."); 
        }
        return con;
    }
    
    
}
