package com.dbcon;

public class SqlQueries {


		//Sql queries to insert, update,display and Delete
		public static final String ins="insert into tb_users "+ "(Policy_Name ,Policy_Holder_Name ,Policy_Start_Date ,Premium_Amount ,Premium_Type) values" + 
				"( ?,?,?,?,?)";
		public static final String updat="update tb_users SET Premium_Type=?   where Policy_Number = ?";
		public static final String disp="select * from tb_users where Policy_Number = ?";
		public static final String del=" delete from tb_users  where Policy_Number = ?";
		
	}
	
	
	

