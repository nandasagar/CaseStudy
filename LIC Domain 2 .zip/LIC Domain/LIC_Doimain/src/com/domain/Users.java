package com.domain;

/* 
    POJO Class  Users is used for increasing the readability and re-usability of a program.
    It represents entity User which encapsulates Business Logic by providing Security. 
 */
public class Users {
	
	private String hname, pdate,premium_type,pname;;
	private float premium_amount;
	private int pno;

	// getter method for pno
	public int getPno() {
		return pno;
	}

	// setter method for pno
	public void setPno(int pno) {
		this.pno = pno;
	}

	// getter method for pname
	public String getPname() {
		return pname;
	}

	// setter method for pname
	public void setPname(String pname) {
		this.pname = pname;
	}
	// getter method for hname
	public String getHname() {
		return hname;
	}

	// setter method for hname
	public void setHname(String hname) {
		this.hname = hname;
	}
	// getter method for pdate
	public String getPdate() {
		return pdate;
	}

	// setter method for pdate
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	
	// getter method for premium_type
	public String getPremium_type() {
		return premium_type;
	}

	// setter method for premium_type
	public void setPremium_type(String premium_type) {
		this.premium_type = premium_type;
	}

	// getter method for premium_amount
	public float getPremium_amount() {
		return premium_amount;
	}

	// setter method for premium_amount
	public void setPremium_amount(float premium_amount) {
		this.premium_amount = premium_amount;
	}

	
	//Parameterized Users Constructor with 5 inputs  to initialize fields 
	public Users(String pname, String hname, String pdate, String premium_type, float premium_amount) {
		super();
		this.pname = pname;
		this.hname = hname;
		this.pdate = pdate;
		this.premium_type = premium_type;
		this.premium_amount = premium_amount;
	}

	// Single parameterized Users Constructor  to initialize fields 
	public Users(int pno2) {
		super();
		this.pno=pno2;
		
	}
	//Default Constructor
	public Users() {
		// TODO Auto-generated constructor stub
	}

	//Parameterized Users Constructor with 2 inputs  to initialize fields 
	public Users(String ptype, int pno2) {
		// TODO Auto-generated constructor stub
		this.premium_type = ptype;
		this.pno=pno2;
	}

	
}
